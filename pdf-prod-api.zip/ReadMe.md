# PDF Generating API

## Configuration
Please set the correct host address in the .env file when you have deployed to the remote backend server.
HOST_ADDRESS = 'https://yourdomain.com';
## Run Server
In hosting server you can simply run 'npm start'
